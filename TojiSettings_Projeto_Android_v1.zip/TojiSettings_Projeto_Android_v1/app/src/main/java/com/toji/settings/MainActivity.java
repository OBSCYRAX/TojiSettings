package com.toji.settings;
import android.app.Activity;
import android.os.Bundle;
public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TojiInterface.show(this);
    }
}

package com.toji.settings;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class TojiInterface {
    private static final int BG = Color.rgb(12, 10, 20);
    private static final int PURPLE = Color.rgb(151, 71, 255);
    private static final int CARD = Color.rgb(28, 23, 43);

    public static void show(final Activity activity) {
        final SharedPreferences prefs = activity.getSharedPreferences("toji", Context.MODE_PRIVATE);
        ScrollView scroll = new ScrollView(activity);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(activity);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = dp(activity, 22);
        root.setPadding(p, dp(activity, 40), p, dp(activity, 28));
        scroll.addView(root);

        TextView title = new TextView(activity);
        title.setText("TOJI SETTINGS");
        title.setTextColor(PURPLE);
        title.setTextSize(29);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView subtitle = new TextView(activity);
        subtitle.setText("BLOOD STRIKE  |  SENSITIVITY");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(activity, 5), 0, dp(activity, 30));
        root.addView(subtitle);

        addSlider(activity, root, prefs, "Geral", 100);
        addSlider(activity, root, prefs, "Mira Red Dot", 90);
        addSlider(activity, root, prefs, "Mira 2x", 85);
        addSlider(activity, root, prefs, "Mira 4x", 75);
        addSlider(activity, root, prefs, "Sniper", 55);
        addSlider(activity, root, prefs, "Camera", 100);

        Button save = new Button(activity);
        save.setText("SALVAR CONFIGURAÇÕES");
        save.setTextColor(Color.WHITE);
        save.setAllCaps(false);
        save.setBackground(shape(PURPLE, dp(activity, 16)));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, dp(activity, 56));
        bp.topMargin = dp(activity, 12);
        root.addView(save, bp);
        save.setOnClickListener(v -> Toast.makeText(activity, "Configurações salvas!", Toast.LENGTH_SHORT).show());

        TextView footer = new TextView(activity);
        footer.setText("TOJI SETTINGS  •  V1.0");
        footer.setTextColor(Color.GRAY);
        footer.setGravity(Gravity.CENTER);
        footer.setPadding(0, dp(activity, 28), 0, dp(activity, 10));
        root.addView(footer);
        activity.setContentView(scroll);
    }

    private static void addSlider(Activity a, LinearLayout root, SharedPreferences prefs, String name, int initial) {
        LinearLayout card = new LinearLayout(a);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(a, 16), dp(a, 14), dp(a, 16), dp(a, 14));
        card.setBackground(shape(CARD, dp(a, 16)));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
        cp.bottomMargin = dp(a, 12);
        root.addView(card, cp);
        TextView label = new TextView(a);
        int saved = prefs.getInt(name, initial);
        label.setText(name + "  •  " + saved);
        label.setTextColor(Color.WHITE);
        label.setTextSize(16);
        card.addView(label);
        SeekBar bar = new SeekBar(a);
        bar.setMax(200);
        bar.setProgress(saved);
        bar.setProgressTintList(ColorStateList.valueOf(PURPLE));
        card.addView(bar);
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int value, boolean user) {
                label.setText(name + "  •  " + value);
                if (user) prefs.edit().putInt(name, value).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
    }
    private static GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }
    private static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }
}

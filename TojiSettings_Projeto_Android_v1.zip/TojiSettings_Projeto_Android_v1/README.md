# Toji Settings
Aplicativo Android demonstrativo para organizar valores de sensibilidade do Blood Strike.

Os controles são salvos localmente no aplicativo. Eles **não alteram automaticamente as configurações do jogo**.

## Gerar APK
Abra a aba Actions > Gerar APK > Run workflow. Após a execução, baixe o artifact `TojiSettings-APK`.
